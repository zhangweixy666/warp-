# warp-go 源码与许可证说明

本目录是 `warp` 可执行文件的 Go 源码归档（逆向实现 Cloudflare WARP 的 MASQUE 代理协议）。

## 许可证

- 本目录内全部源码与文档：MIT License，版权归 `zhangweixy666` 所有，全文见同目录 `LICENSE`。
- 本目录不包含 Cloudflare `warp-svc` 的任何源代码或二进制文件。
  `docs/warp-masque-reverse-engineering.md` 是对公开二进制网络行为的独立逆向分析记录，
  仅供协议互操作性研究使用。

## 第三方依赖（均为上游公开库，许可证见括号）

| 依赖 | 用途 | 许可证 |
| --- | --- | --- |
| `github.com/quic-go/quic-go` | QUIC / HTTP-3 传输 | MIT |
| `github.com/quic-go/qpack` | QPACK 头部压缩 | MIT |
| `golang.org/x/crypto` | 密码学原语 | BSD-3-Clause |
| `golang.org/x/net` | HTTP/2、QUIC 支撑 | BSD-3-Clause |
| `golang.org/x/sys` | 系统调用封装 | BSD-3-Clause |
| `golang.org/x/text` | 字符编码处理 | BSD-3-Clause |
| Go 运行时标准库 | 编译与运行 | BSD-3-Clause |

上述依赖以 Go module 方式引入，源码不随本归档分发；构建时由 `go mod download`
自行获取，各自保留其上游许可证。

## 构建

```sh
go build -trimpath -ldflags='-s -w' -o warp .
```

要求 Go 版本见 `go.mod`。构建产物 `warp` 通过 GitHub Release 分发，
不提交进代码仓库。

## 使用须知

使用前请自行确认符合所在地法律法规及 Cloudflare 服务条款。
本项目仅供学习、研究和个人测试使用。
